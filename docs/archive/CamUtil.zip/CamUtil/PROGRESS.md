# camutil Progress / Integration

Date: 2026-02-04

## Architecture (Unified)

- **pi-logger** is the event source (`/v1/events?limit=N`).
- **camutil spine (Node/TS server)** ingests, normalizes, tracks node IPs, and emits:
  - `GET /health`, `GET /metrics`, `GET /nodes`
  - `WS /ws/events` (canonical events)
  - `WS /ws/frames` (render frames)
  - `GET /` (spectrum UI)
- **Mac app (CamUtil)** connects to camutil via `/ws/events` and `/nodes`.
- Legacy cockpit shim removed; camutil CLI is primary.

## Repo Audit

### camutil (`/Users/letsdev/CamUtil`)
- Entrypoints:
  - Mac app: `CamUtil/CamUtilApp.swift`
  - Spine server: `server/src/cli.ts` (CLI) and `server/src/server.ts` (HTTP/WS)
  - Spectrum UI: `server/public/index.html`, `spectrum.js`, `spectrum.css`
- Build/Run:
  - Server dev: `npm run dev -- --pi-logger http://pi-logger.local:8088 --port 9123`
  - Server prod: `npm run build && node dist/cli.js start ...`
  - Mac app: open `CamUtil/CamUtil.xcodeproj` in Xcode, build/run
- Event schema (canonical):
  - `CanonicalEvent`: `id? recv_ts event_ts node_id kind severity summary data`
  - `SignalFrame`: `t source node_id device_id channel frequency rssi color persistence velocity? confidence`
- Visualization:
  - Web spectrum UI (Canvas2D) consumes `/ws/frames`
  - Mac app Spectral view consumes `/ws/events`

### node-agent (`/Users/letsdev/CamUtil/node-agent`)
- Entrypoint: `src/main.cpp`
- Build/Stage: `./tools/build-stage-esp32dev.sh`, `./tools/build-stage-esp32c3.sh`
- Flash: `./tools/flash-esp32dev.sh`, `./tools/flash-esp32c3.sh`
- Event schema:
  - `node.boot`, `node.heartbeat`, `wifi.status`, `node.announce`, `ble.seen`

### CLI
- Entrypoint: `/Users/letsdev/CamUtil/tools/camutil`

## Exact Commands

Start camutil spine:
```bash
cd /Users/letsdev/CamUtil/server
npm install
npm run dev -- --pi-logger http://pi-logger.local:8088 --port 9123
```

Open spectrum:
```bash
/Users/letsdev/CamUtil/tools/camutil spectrum
```

CLI:
```bash
/Users/letsdev/CamUtil/tools/camutil whereis lab-esp32-01
/Users/letsdev/CamUtil/tools/camutil open lab-esp32-01
/Users/letsdev/CamUtil/tools/camutil tail
```

## Verification Checklist (No Serial)

1. Start camutil spine and confirm `/health` returns `ok`.
2. Power-cycle ESP nodes.
3. `GET /nodes` shows `node_id`, `ip`, `last_seen`.
4. `curl http://<ip>/whoami` returns JSON.
5. Spectrum UI shows distinct device colors and trails.

## Notes

- `/v1/events` provides **node_id + limit only**. camutil filters by kind client-side.
- JSON parse errors increment `events_bad_json` and emit camutil errors without crashing.
