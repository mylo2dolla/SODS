#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${1:-http://localhost:9123}"

check() {
  local path="$1"
  local url="$BASE_URL$path"
  echo "Checking $url"
  curl -fsS "$url" >/dev/null
}

check "/health"
check "/metrics"
check "/nodes"

WS_EVENTS=$(python3 - <<'PY'
import sys, json, asyncio
import websockets

async def main():
    url = sys.argv[1]
    try:
        async with websockets.connect(url) as ws:
            msg = await asyncio.wait_for(ws.recv(), timeout=2.5)
            print("ok")
    except Exception as e:
        print("fail")

asyncio.run(main())
PY
"$(echo "$BASE_URL" | sed 's#http#ws#')/ws/events")

if [[ "$WS_EVENTS" != "ok" ]]; then
  echo "ws /ws/events failed"
  exit 1
fi

echo "verify ok"
