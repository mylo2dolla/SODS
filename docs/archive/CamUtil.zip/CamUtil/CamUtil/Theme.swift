import SwiftUI

enum Theme {
    static let background = Color.black
    static let panel = Color(red: 0.10, green: 0.10, blue: 0.12)
    static let panelAlt = Color(red: 0.14, green: 0.14, blue: 0.16)
    static let border = Color.white.opacity(0.08)
    static let accent = Color(red: 0.92, green: 0.18, blue: 0.20)
    static let textPrimary = Color.white
    static let textSecondary = Color.white.opacity(0.65)
    static let muted = Color.white.opacity(0.4)

    static func statusColor(ok: Bool) -> Color {
        ok ? accent : muted
    }

    static func cardStyle() -> some ViewModifier {
        CardStyle()
    }

    private struct CardStyle: ViewModifier {
        func body(content: Content) -> some View {
            content
                .padding(12)
                .background(Theme.panel)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Theme.border, lineWidth: 1)
                )
                .cornerRadius(10)
        }
    }
}

struct PrimaryActionButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 12, weight: .semibold))
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(Theme.accent.opacity(configuration.isPressed ? 0.6 : 0.8))
            .foregroundColor(.white)
            .cornerRadius(6)
            .shadow(color: Theme.accent.opacity(0.3), radius: 6, x: 0, y: 2)
    }
}

struct SecondaryActionButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 12, weight: .semibold))
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(Theme.panelAlt.opacity(configuration.isPressed ? 0.8 : 1.0))
            .foregroundColor(Theme.textPrimary)
            .cornerRadius(6)
            .overlay(
                RoundedRectangle(cornerRadius: 6)
                    .stroke(Theme.border, lineWidth: 1)
            )
    }
}
