# Camutil (Spine Runtime + Mac App)

Camutil is the spine: it ingests pi-logger events, normalizes into canonical events/frames, serves a spectrum UI, and powers the Mac app and CLI.

## Quickstart

1) Start camutil spine:
```bash
cd /Users/letsdev/CamUtil/server
npm install
npm run dev -- --pi-logger http://pi-logger.local:8088 --port 9123
```

2) Open spectrum:
```bash
/Users/letsdev/CamUtil/tools/camutil spectrum
```

3) Verify:
```bash
/Users/letsdev/CamUtil/tools/verify.sh
```

## Mac App Build

1. Open `CamUtil/CamUtil.xcodeproj` in Xcode.
2. Select the `CamUtil` scheme.
3. Build and run.

The built app appears in Xcode's DerivedData folder under `Build/Products/Debug/CamUtil.app` (or `Release/CamUtil.app` for release builds).

## Spine Server

Install deps:
```bash
cd /Users/letsdev/CamUtil/server
npm install
```

Dev (watch):
```bash
npm run dev -- --pi-logger http://pi-logger.local:8088 --port 9123
```

Build + run (offline once deps installed):
```bash
npm run build
node dist/cli.js start --pi-logger http://pi-logger.local:8088 --port 9123
```

CLI:
```bash
/Users/letsdev/CamUtil/tools/camutil whereis lab-esp32-01
/Users/letsdev/CamUtil/tools/camutil open lab-esp32-01
/Users/letsdev/CamUtil/tools/camutil spectrum
```

Demo/replay mode:
```bash
/Users/letsdev/CamUtil/tools/camutil stream --frames --out /Users/letsdev/CamUtil/server/public/demo.ndjson
open "http://localhost:9123/?demo=1"
```

## Visualizer + Node Discovery

The spectrum UI is served by the camutil spine and consumes `/ws/frames`. The Mac app uses camutil `/ws/events` and `/nodes` for node discovery. IPs are extracted from `node.announce` and `wifi.status`.

To configure the feed, open **Spectral** and set **Camutil URL** (default `http://localhost:9123`). The visualizer shows **Connected / Degraded / Offline** based on camutil health.

## How To Verify (No Serial)

1. Ensure pi-logger is running and `/v1/events` returns items.
2. Start camutil spine (`npm run dev -- --pi-logger http://pi-logger.local:8088 --port 9123`).
3. In the app, set **Camutil URL** to `http://localhost:9123` and click **Open Spectrum**.
4. Confirm nodes populate and `/whoami`, `/health`, `/metrics` open for nodes with IPs.
5. Verify spectrum shows distinct colors and trails for BLE/Wi-Fi events.

## Flash (ESP32 / ESP32-C3)

Use the **Flash Node** panel in the app:

- Pick target `ESP32 DevKit v1` or `ESP32-C3 DevKitM-1`
- Click **Connect / Flash Node** to start the local server and open ESP Web Tools
- Click **Open Local Flasher** to open the local ESP Web Tools URL for the selected target
