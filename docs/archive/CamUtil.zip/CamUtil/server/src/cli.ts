#!/usr/bin/env node
import { CamutilServer } from "./server.js";
import { WebSocket } from "ws";
import { createWriteStream } from "node:fs";
import { spawn } from "node:child_process";

const args = process.argv.slice(2);
const cmd = args[0] ?? "help";

function getArg(flag: string, fallback?: string) {
  const idx = args.indexOf(flag);
  if (idx === -1) return fallback;
  const val = args[idx + 1];
  if (!val || val.startsWith("--")) return fallback;
  return val;
}

function hasFlag(flag: string) {
  return args.includes(flag);
}

function positional(index: number): string | undefined {
  const list = args.filter((a) => !a.startsWith("--"));
  return list[index];
}

function usage(exitCode = 0) {
  console.log(`camutil <command> [options]

Commands:
  start --pi-logger <url> --port <port>
  whereis <node_id> [--base <url>]
  open <node_id> [--base <url>]
  spectrum [--base <url>]
  tail [--base <url>]
  stream --frames [--base <url>] [--out <path>]

Defaults:
  --pi-logger http://pi-logger.local:8088
  --port 9123
  --base http://localhost:9123
`);
  process.exit(exitCode);
}

function baseURL() {
  return (getArg("--base", "http://localhost:9123") ?? "http://localhost:9123").replace(/\/+$/, "");
}

async function httpJson(path: string) {
  const url = `${baseURL()}${path}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function cmdStart() {
  const piLogger = getArg("--pi-logger", "http://pi-logger.local:8088")!;
  const port = Number(getArg("--port", "9123"));
  if (!piLogger.startsWith("http")) {
    console.error("Invalid --pi-logger URL");
    process.exit(1);
  }
  const server = new CamutilServer({
    port,
    piLoggerBase: piLogger,
    publicDir: new URL("../public/", import.meta.url).pathname,
  });
  server.start();
  console.log(`camutil running on http://localhost:${port}`);
}

async function cmdWhereis() {
  const nodeId = positional(1);
  if (!nodeId) return usage(1);
  const nodes = await httpJson("/nodes");
  const items = nodes.items ?? [];
  const match = items.find((n: any) => n.node_id === nodeId);
  if (!match) {
    console.error("Node not found");
    process.exit(2);
  }
  console.log(`node_id:   ${match.node_id}`);
  console.log(`ip:        ${match.ip ?? "?"}`);
  console.log(`hostname:  ${match.hostname ?? "?"}`);
  console.log(`mac:       ${match.mac ?? "?"}`);
  console.log(`last_seen: ${new Date(match.last_seen).toISOString()}`);
  console.log(`confidence:${(match.confidence ?? 0).toFixed(2)}`);
}

async function cmdOpen() {
  const nodeId = positional(1);
  if (!nodeId) return usage(1);
  const nodes = await httpJson("/nodes");
  const items = nodes.items ?? [];
  const match = items.find((n: any) => n.node_id === nodeId);
  if (!match || !match.ip) {
    console.error("Node IP not found");
    process.exit(2);
  }
  const ip = match.ip;
  const urls = [`http://${ip}/health`, `http://${ip}/metrics`, `http://${ip}/whoami`, `http://${ip}/wifi`];
  for (const url of urls) {
    console.log(url);
    if (process.platform === "darwin") spawn("open", [url], { stdio: "ignore", detached: true }).unref();
  }
}

async function cmdSpectrum() {
  const url = `${baseURL()}/`;
  console.log(url);
  if (process.platform === "darwin") spawn("open", [url], { stdio: "ignore", detached: true }).unref();
}

async function cmdTail() {
  const wsURL = baseURL().replace(/^http/, "ws") + "/ws/events";
  const ws = new WebSocket(wsURL);
  ws.on("message", (data) => {
    process.stdout.write(String(data) + "\n");
  });
  ws.on("error", (err) => {
    console.error(err.message);
    process.exit(2);
  });
}

async function cmdStream() {
  if (!hasFlag("--frames")) return usage(1);
  const wsURL = baseURL().replace(/^http/, "ws") + "/ws/frames";
  const outPath = getArg("--out", "");
  const out = outPath ? createWriteStream(outPath) : null;
  const ws = new WebSocket(wsURL);
  ws.on("message", (data) => {
    const line = String(data);
    if (out) {
      out.write(line + "\n");
    } else {
      process.stdout.write(line + "\n");
    }
  });
  ws.on("error", (err) => {
    console.error(err.message);
    process.exit(2);
  });
}

if (cmd === "start") {
  await cmdStart();
} else if (cmd === "whereis") {
  await cmdWhereis();
} else if (cmd === "open") {
  await cmdOpen();
} else if (cmd === "spectrum") {
  await cmdSpectrum();
} else if (cmd === "tail") {
  await cmdTail();
} else if (cmd === "stream") {
  await cmdStream();
} else {
  usage(cmd === "help" ? 0 : 1);
}
