const canvas = document.getElementById("field");
const ctx = canvas.getContext("2d");
const statusEl = document.getElementById("status");
const pauseBtn = document.getElementById("pauseBtn");
const windowSelect = document.getElementById("windowSelect");
const nodeFilterInput = document.getElementById("nodeFilter");
const capRange = document.getElementById("capRange");
const capValue = document.getElementById("capValue");
const demoToggle = document.getElementById("demoToggle");

let paused = false;
let timeWindowMs = Number(windowSelect.value);
let deviceCap = Number(capRange.value);
let nodeFilter = "";
let useDemo = false;

capValue.textContent = String(deviceCap);

pauseBtn.addEventListener("click", () => {
  paused = !paused;
  pauseBtn.textContent = paused ? "Resume" : "Pause";
});

windowSelect.addEventListener("change", () => {
  timeWindowMs = Number(windowSelect.value);
});

nodeFilterInput.addEventListener("input", () => {
  nodeFilter = nodeFilterInput.value.trim();
});

capRange.addEventListener("input", () => {
  deviceCap = Number(capRange.value);
  capValue.textContent = String(deviceCap);
});

demoToggle.addEventListener("change", () => {
  useDemo = demoToggle.checked;
  resetStream();
});

const params = new URLSearchParams(window.location.search);
if (params.get("demo") === "1") {
  demoToggle.checked = true;
  useDemo = true;
}

const trails = new Map();
const maxTrailPoints = 80;
const framesBuffer = [];

function resize() {
  const ratio = window.devicePixelRatio || 1;
  canvas.width = canvas.clientWidth * ratio;
  canvas.height = canvas.clientHeight * ratio;
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
}

window.addEventListener("resize", resize);
resize();

function pushTrail(frame) {
  if (!trails.has(frame.device_id)) {
    trails.set(frame.device_id, []);
  }
  const list = trails.get(frame.device_id);
  list.push(frame);
  if (list.length > maxTrailPoints) list.splice(0, list.length - maxTrailPoints);
}

function renderFrame() {
  requestAnimationFrame(renderFrame);
  if (paused) return;

  const now = Date.now();
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;

  ctx.clearRect(0, 0, width, height);
  drawBackground(width, height, now);

  const active = Array.from(trails.entries())
    .map(([id, list]) => ({ id, list }))
    .sort((a, b) => (b.list.at(-1)?.persistence ?? 0) - (a.list.at(-1)?.persistence ?? 0))
    .slice(0, deviceCap);

  for (const { list } of active) {
    drawTrail(list, width, height, now);
  }
}

function drawBackground(width, height, now) {
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, "rgba(14, 16, 28, 1)");
  gradient.addColorStop(0.5, "rgba(9, 10, 18, 1)");
  gradient.addColorStop(1, "rgba(8, 10, 14, 1)");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  ctx.save();
  ctx.strokeStyle = "rgba(120,130,160,0.06)";
  ctx.lineWidth = 1;
  const grid = 40;
  for (let x = 0; x < width; x += grid) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }
  for (let y = 0; y < height; y += grid) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }
  ctx.restore();

  const pulse = 0.6 + 0.4 * Math.sin(now * 0.0004);
  ctx.fillStyle = `rgba(80, 110, 180, ${0.08 * pulse})`;
  ctx.beginPath();
  ctx.arc(width * 0.5, height * 0.55, 280, 0, Math.PI * 2);
  ctx.fill();
}

function drawTrail(list, width, height, now) {
  const recent = list.filter((f) => now - f.t <= timeWindowMs);
  if (recent.length === 0) return;

  const last = recent[recent.length - 1];
  const x = mapFrequency(last.frequency, width);
  const baseY = mapDepth(last, height);

  ctx.save();
  ctx.strokeStyle = colorWithAlpha(last.color, 0.25);
  ctx.lineWidth = 2 + last.persistence * 6;
  ctx.beginPath();
  for (let i = 0; i < recent.length; i++) {
    const frame = recent[i];
    const fx = mapFrequency(frame.frequency, width);
    const fy = mapDepth(frame, height) + jitter(frame.device_id, i) * 8;
    if (i === 0) ctx.moveTo(fx, fy);
    else ctx.lineTo(fx, fy);
  }
  ctx.stroke();

  const glow = 12 + last.persistence * 30;
  ctx.fillStyle = colorWithAlpha(last.color, 0.2 + last.persistence * 0.4);
  ctx.beginPath();
  ctx.ellipse(x, baseY, glow, glow * 0.6, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = colorWithAlpha(last.color, 0.9);
  ctx.beginPath();
  ctx.ellipse(x, baseY, 3 + last.persistence * 6, 3 + last.persistence * 5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function mapDepth(frame, height) {
  const strength = clamp((frame.rssi + 95) / 60, 0, 1);
  const depth = 0.2 + strength * 0.75;
  return height * (0.15 + (1 - depth) * 0.75);
}

function mapFrequency(freq, width) {
  if (freq < 3000) {
    return width * ((freq - 2400) / 200);
  }
  const f = clamp((freq - 5000) / 900, 0, 1);
  return width * (0.55 + f * 0.45);
}

function colorWithAlpha(color, alpha) {
  return `hsla(${color.h}, ${Math.round(color.s * 100)}%, ${Math.round(color.l * 100)}%, ${alpha})`;
}

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

function jitter(seed, idx) {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) h ^= seed.charCodeAt(i);
  h = Math.imul(h + idx * 1013, 16777619);
  return ((h >>> 0) % 1000) / 1000 - 0.5;
}

let ws;
let demoTimer;

function connectWS() {
  const url = new URL("/ws/frames", window.location.href);
  url.protocol = url.protocol.replace("http", "ws");
  ws = new WebSocket(url.toString());
  ws.addEventListener("open", () => {
    statusEl.textContent = "live";
  });
  ws.addEventListener("close", () => {
    statusEl.textContent = "disconnected";
  });
  ws.addEventListener("message", (event) => {
    const payload = JSON.parse(event.data);
    const frames = payload.frames ?? [];
    for (const frame of frames) {
      if (nodeFilter && frame.node_id !== nodeFilter) continue;
      pushTrail(frame);
    }
  });
}

async function startDemo() {
  statusEl.textContent = "demo";
  const res = await fetch("/demo.ndjson");
  if (!res.ok) {
    statusEl.textContent = "demo missing";
    return;
  }
  const text = await res.text();
  const lines = text.trim().split("\n");
  let idx = 0;
  demoTimer = setInterval(() => {
    if (paused) return;
    const line = lines[idx++ % lines.length];
    if (!line) return;
    const payload = JSON.parse(line);
    const frames = payload.frames ?? [];
    for (const frame of frames) {
      if (nodeFilter && frame.node_id !== nodeFilter) continue;
      pushTrail(frame);
    }
  }, 1000 / 30);
}

function resetStream() {
  if (ws) {
    ws.close();
    ws = null;
  }
  if (demoTimer) {
    clearInterval(demoTimer);
    demoTimer = null;
  }
  if (useDemo) startDemo();
  else connectWS();
}

resetStream();
renderFrame();
